<html>
  <head>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script>
      var chart;

      function requestData() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'http://smartcampus.ctd.ifsp.edu.br/graficos/novosdados10b.php', true);
        xhr.onreadystatechange = function() {
          if (xhr.readyState === 4) {
            if (xhr.status === 200) {
              var data = JSON.parse(xhr.responseText);
             
             var temperature = data.temperature;
             var timestamp = data.timestamp;
           // var temperature=data[1];
          //  var timestamp==data[0];
              console.log([timestamp, temperature]);
              chart.series[0].addPoint([timestamp, temperature]);
            }
          }
        };
        xhr.send();
      }

      document.addEventListener('DOMContentLoaded', function() {
        chart = Highcharts.chart('container', {
          chart: {
            type: 'spline',
            animation: Highcharts.svg,
            events: {
              load: requestData
            }
          },
          title: {
            text: 'Temperatura ao vivo'
          },
          xAxis: {
            type: 'datetime',
            tickPixelInterval: 150
          },
          yAxis: {
            title: {
              text: 'Temperatura (°C)'
            },
            plotLines: [{
              value: 0,
              width: 1,
              color: '#808080'
            }]
          },
 
          series: [{
            name: 'Temperatura',
            data: []
          }]
        });
      });

      setInterval(function() {
        requestData();
      }, 1000);
    </script>
  </head>
  <body>
    <div id="container" style="width: 100%; height: 400px; margin: 0 auto"></div>
  </body>
</html>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
</head>
<body>

    <BR>
    <BR>
    <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

</body>
</html>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>


<script>
Highcharts.chart('container', {
  chart: {
    type: 'column'
  },
  title: {
    text: "Browsers mais populares em 2017"
  },
  xAxis: {
    categories: ["Firefox", "Chrome", "IE/Edge", "Safari", "Opera"]
  },
  subtitle: {
    text: "Source: Site W3Counter (www.w3counter.com) - Dados em %"
  },
  yAxis: {
    title: {
      text: "Porcentagem"
    }
  },
  tooltip: {
        enabled: false
    },
  legends: {
    enabled: false
  },
  series: [{
    data: [9.3, 58.8, 8, 14.5, 4],
    showInLegend: false,
    colorByPoint: true
  }]
})
</script>
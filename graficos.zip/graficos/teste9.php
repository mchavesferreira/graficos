<?php
// Conexão com o banco de dados
$conn = mysqli_connect("localhost", "username", "password", "database_name");

// Verificação da conexão
if (!$conn) {
    die("Conexão falhou: " . mysqli_connect_error());
}

// Query para recuperar as últimas 24 horas de dados
$query = "SELECT * FROM dados WHERE timestamp >= NOW() - INTERVAL 24 HOUR";
$result = mysqli_query($conn, $query);

// Array para armazenar os dados de temperatura e umidade
$temperature_data = array();
$humidity_data = array();

// Loop para preencher os arrays com os dados do banco de dados
while ($row = mysqli_fetch_assoc($result)) {
    $timestamp = strtotime($row['timestamp']) * 1000;
    $temperature = (float)$row['temperature'];
    $humidity = (float)$row['humidity'];
    $temperature_data[] = [$timestamp, $temperature];
    $humidity_data[] = [$timestamp, $humidity];
}

// Fecha a conexão com o banco de dados
mysqli_close($conn);
?>

<html>
  <head>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script>
      $(document).ready(function() {
        // Cria o gráfico
        var chart = Highcharts.chart('container', {
          chart: {
            type: 'spline',
            events: {
              load: function() {
                // Atualiza o gráfico a cada 10 segundos
                setInterval(function() {
                  $.getJSON('novosdados.php', function(data) {
                    chart.series[0].addPoint([data[0], data[1]]);
                    chart.series[1].addPoint([data[0], data[2]]);
                  });
                }, 10000);
              }
            }
          },
          title: {
            text: 'Temperatura e Umidade'
          },
          xAxis: {
            type: 'datetime',
            labels: {
              formatter: function() {
                return Highcharts.dateFormat('%d/%m/%Y %H:%M:%S', this.value);
              }
            }
          },
          yAxis: [{
            title: {
              text: 'Temperatura (°C)'
            },
            min: 0
          }, {
            title: {
              text: 'Umidade (%)'
            },
            opposite: true,
            min: 0
          }],
          series: [{
            name: 'Temperatura',
            data: <?php echo json_encode($temperature_data); ?>,
            y

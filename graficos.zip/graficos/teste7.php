<html>
  <head>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script>
      function getData() {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "ultimo.php", true);
        xhr.onreadystatechange = function () {
          if (xhr.readyState === 4 && xhr.status === 200) {
            var temperature = JSON.parse(xhr.responseText);
            var chart = Highcharts.chart('container', {
              chart: {
                type: 'line'
              },
              title: {
                text: 'Gráfico de Temperatura'
              },
              xAxis: {
                categories: temperature.time
              },
              yAxis: {
                title: {
                  text: 'Temperatura (°C)'
                }
              },
              series: [{
                name: 'Temperatura',
                data: temperature.data
              }]
            });
          }
        };
        xhr.send();
      }

      window.setInterval(function () {
        getData();
      }, 5000);
    </script>
  </head>
  <body onload="getData()">
    <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
  </body>
</html>

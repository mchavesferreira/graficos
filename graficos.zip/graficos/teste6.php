
<!DOCTYPE html>
<html lang='en-US'>
  <head>
    <link rel="icon" type="image/x-icon" href="https://www.highcharts.com/demo/static/favicon.ico">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="googlebot" content="nofollow">
    <title>Highcharts Demo</title>

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    
    <style>
  body {
    margin: 0;
    color: #313131;
    font-family: sans-serif;
    min-width: 300px;
  }
  body.toc{
    font-family: 'Roboto', sans-serif;
    font-size: 15px;
  }
  h1 {
    font-size: 2em;
    margin: 0.67em 0;
    font-weight: bolder;
    text-transform: uppercase;
  }
  h2 {
    font-size: 1.5em;
    margin: 0.83em 0;
    font-weight: bolder;
    text-transform: uppercase;
  }
  h3 {
    font-size: 1.17em;
    margin: 1em 0;
    font-weight: bolder;
    text-transform: uppercase;
  }
  h4 {
    font-weight: bolder;
    text-transform: uppercase;
  }

  .highcharts-samples-navbar {
    background-color: #47475C;
    height: 50px;
  }
  .highcharts-samples-navbar .sample-navbar-brand img {
    height: 66px;
    margin-top: auto;
    margin-bottom: auto;
    height: auto;
    max-height: 95%;
    margin-left: 5px;
    width: auto;
    max-width: 50vw;
  }
  .actions {
    float: right;
    max-width: 50vw;
  }
  .action {
    float: right;
    line-height: 50px;
    margin-right: 10px;
    text-decoration: none;
    font-size: 0.8em;
  }
  a.action {
    color: #424BCD;
  }
  a.action:hover {
    text-decoration: underline;
  }
  .action i.fab {
    font-size: 1.6em;
  }
  .action i.fa-jsfiddle {
    font-weight: 700;
  }
  .highcharts-samples-navbar a.action {
    color: #eeeaea;
  }
  .description {
    max-width: 800px;
    margin: 1em auto;
    padding: 10px;
  }
  .error {
    text-align: center;
    font-style: italic;
    color: red;
  }

  .embed .highcharts-samples-navbar {
    background-color: #EBEBEB;
    color: #3d3d3d;
    height: 50px;
  }
  .embed .sample-navbar-brand {
    display: none;
  }
  .embed a.action {
    color: #424BCD;
  }

  .nonav .highcharts-samples-navbar {
    display: none;
  }

  li{
    max-width: 60rem;
  }

  ul, menu, dir {
    display: block;
    list-style-type: disc;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    padding-inline-start: 40px;
    line-height: 1.25rem;
}

@media only screen and (max-width: 800px) {
  .actions .action {
    font-size: 0.65em;
  }
}


</style>
    <style id="demoStyle">

    </style>

  </head>
  <body>
    
<div class="highcharts-samples-navbar">
  <a href="https://www.highcharts.com" class="sample-navbar-brand" title="Highcharts">
    <img src="https://wp-assets.highcharts.com/svg/highcharts-logo-padded.svg" alt="Highcharts">
  </a>
  <div class="actions">
    <a href="https://www.highcharts.com/samples/highcharts/data/livedata-fetch?codepen" id="codepenButton" target="_blank" rel="noreferrer noopener" class="action">
      <i class="fab fa-codepen"></i> CodePen
    </a>

      <a href="https://jsfiddle.net/gh/get/library/pure/highcharts/highcharts/tree/master/samples/highcharts/data/livedata-fetch" class="action" target="_blank" rel="noreferrer noopener">
      <i class="fab fa-jsfiddle"></i> jsFiddle
    </a>
  </div>
</div>


    <main>
<script src="https://code.highcharts.com/highcharts.js"></script>

<div id="container"></div>
    </main>

    <script>
      window.initialHTML = document.querySelector('main').innerHTML;
    </script>

    <script id="js" >
let chart; // global

/**
 * Request data from the server, add it to the graph and set a timeout to request again
 * https://demo-live-data.highcharts.com/time-rows.json
 */ 
async function requestData() {
    const result = await fetch('http://smartcampus.ctd.ifsp.edu.br/php/ultimostemperatura2.php');
    if (result.ok) {
        const data = await result.json();

        const [date, value] = data[0];
        const point = [new Date(date).getTime(), value * 10];
        const series = chart.series[0],
        shift = series.data.length > 20; // shift if the series is longer than 20

        // add the point
        chart.series[0].addPoint(point, true, shift);
        // call it again after one second
        setTimeout(requestData, 1000);
    }
}

window.addEventListener('load', function () {
    chart = new Highcharts.Chart({
        chart: {
            renderTo: 'container',
            defaultSeriesType: 'spline',
            events: {
                load: requestData
            }
        },
        title: {
            text: 'Live random data'
        },
        xAxis: {
            type: 'datetime',
            tickPixelInterval: 150,
            maxZoom: 20 * 1000
        },
        yAxis: {
            minPadding: 0.2,
            maxPadding: 0.2,
            title: {
                text: 'Value',
                margin: 80
            }
        },
        series: [{
            name: 'Random data',
            data: []
        }]
    });
});
    </script>

<script>
function sendToCodepen(e){
    if(e){
      e.preventDefault();
    }
    const demoContent = {};
    const html = window.initialHTML;
    demoContent.html = html.trim();
    demoContent.css = document.querySelector('#demoStyle').innerHTML.trim();
    demoContent.js = document.querySelector('#js').innerHTML.trim();

      const data = {
        title: document.title,
        ...demoContent
      };
      const JSONstring = JSON.stringify(data)
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;")
        .replace(/\s\s\s\s/g, '  ');

      const form = document.createElement('form');
      form.id = "codepen-form";
      form.style = "display:none;";
      form.action = "https://codepen.io/pen/define";
      form.method = "POST";
      form.innerHTML ='<input type="hidden" name="data" value=\'' +
      JSONstring +
      '\'>';

      document.body.appendChild(form);

      form.submit();
      document.querySelector('main').innerHTML =
      '<div style="margin: 2em auto; text-align: center;">Sending you to CodePen <span class="fa fa-spinner fa-spin"></span></div>';
}

if(window.location.search.includes('codepen')){
  sendToCodepen();
}

document.querySelector('#codepenButton').addEventListener('click', sendToCodepen);
</script>

  </body>
</html>

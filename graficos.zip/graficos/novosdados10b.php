<?php

// Connect to the database
$servername = "localhost"; //padrão - server local
$dbname = "sensor"; //alterar conforme o nome do seu banco de dados
$username = "root"; //padrão - root
$password = "S&nh@123";//senha de conexão do banco de dados.

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the latest temperature and humidity data from the database
$sql = "SELECT TEMP, UR, time FROM cetesbcatanduvamedhor ORDER BY time DESC LIMIT 1";
$result = $conn->query($sql);



// If there are results, return the latest temperature and humidity data
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $temperature = $row["TEMP"];
        $humidity = $row["UR"];
        $timestamp = $row["time"];
    }
}
$timestamp  = time()*1000 ;
$temperature= rand(2,30);

// Return the latest temperature and humidity data in JSON format
$data = array(
    "temperature" => $temperature,
    "timestamp" => $timestamp
);

header('Content-Type: application/json');
echo json_encode($data);

// Close the database connection
$conn->close();

?>

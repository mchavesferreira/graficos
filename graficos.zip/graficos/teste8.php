<html>
  <head>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script>
      function getData() {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "ultimodado8.php", true);
        xhr.onreadystatechange = function () {
          if (xhr.readyState === 4 && xhr.status === 200) {
            var data = JSON.parse(xhr.responseText);
            var chart = Highcharts.chart('container', {
              chart: {
                type: 'line'
              },
              title: {
                text: 'Gráfico de Temperatura e Umidade'
              },
              xAxis: {
                type: 'datetime',
                labels: {
                  format: '{value:%Y-%m-%d %H:%M:%S}'
                }
              },
              yAxis: [{
                labels: {
                  format: '{value}°C'
                },
                title: {
                  text: 'Temperatura'
                }
              }, {
                labels: {
                  format: '{value}%'
                },
                title: {
                  text: 'Umidade'
                },
                opposite: true
              }],
              series: [{
                name: 'Temperatura',
                type: 'line',
                data: data.temperature,
                yAxis: 0
              }, {
                name: 'Umidade',
                type: 'line',
                data: data.humidity,
                yAxis: 1
              }]
            });
          }
        };
        xhr.send();
      }

      window.setInterval(function () {
        getData();
      }, 5000);
    </script>
  </head>
  <body onload="getData()">
    <div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
  </body>
</html>

<?php
  header('Content-Type: application/json');
  $conn = new mysqli('localhost', 'user', 'password', 'database');
  $result = $conn->query('SELECT UNIX_TIMESTAMP(time) as time, temperature, humidity FROM temperature_humidity ORDER BY time DESC LIMIT 10');
  $data = array(
    'temperature' => array(),
    'humidity' => array()
  );
  while ($row = $result->fetch_assoc()) {
    array_push($data['temperature'], [$row['time'] * 1000, (float)$row['temperature']]);
    array_push($data['humidity'], [$row['time'] * 1000, (float)$row['humidity']]);
  }
 
  echo json_encode($data);
?>
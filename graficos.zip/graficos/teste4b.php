<html>
   <head>
      <title>Highcharts Tutorial</title>
      <script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
      </script>
      <script src = "https://code.highcharts.com/highcharts.js"></script>  
   </head>
   
   <body>
      <div id = "container" style = "width: 550px; height: 400px; margin: 0 auto"></div>
      <script language = "JavaScript">
         $(document).ready(function() {
            var chart = {
               type: 'spline',
               animation: Highcharts.svg, // don't animate in IE < IE 10.
               marginRight: 10,
               
               events: {
                  load: function () {
                     // set up the updating of the chart each second
                     ///(new Date()).getTime();
                     var series = this.series[0];
                     
                     setInterval(function() {
                        $.getJSON('http://smartcampus.ctd.ifsp.edu.br/php/ultimostemperaturadatae.php', function (data) {
                            var x= data[0];
                          //  var date = Date.parse(data[0] +'GMT-0300');
                            var y=data[1];
                            var valor=[x,y];
                          //  series.addPoint(valor);
                            series.addPoint([x, y]);
                            console.log(valor);
                        }); 
                    }, 5000);
                  }
               }
            };
            var title = {
               text: 'Live random data'   
            };   
            var xAxis = {
               type: 'datetime',
               tickPixelInterval: 1500
            };
            var yAxis = {
               title: {
                  text: 'Value'
               },
               plotLines: [{
                  value: 0,
                  width: 1,
                  color: '#808080'
               }]
            };
            var tooltip = {
               formatter: function () {
               return '<b>' + this.series.name + '</b><br/>' +
                  Highcharts.dateFormat('%H:%M:%S %d/%m/%Y', this.x) + '<br/>' +
                  Highcharts.numberFormat(this.y, 2);
               }
            };
            var plotOptions = {
               area: {
                  allowPointSelect: true,
                  pointStart: 2023,
                  marker: {
                     enabled: false,
                     symbol: 'circle',
                     radius: 2,
                     
                     states: {
                        hover: {
                           enabled: true
                        }
                     }
                  }
               }
            };
            var legend = {
               enabled: false
            };
            var exporting = {
               enabled: false
            };
            var series = [{
               name: 'Random data',
               data: (function () {
                  // generate an array of random data
                  var data = [],time = (new Date()).getTime(),i;
                  
                  for (i = -10; i <= 0; i += 1) {
                     data.push({
                        x: time + i * 1000,
                        y: Math.random()
                     });
                  }
                  return data;
               }())    
            }];     
      
            var json = {};   
            json.chart = chart; 
            json.title = title;     
            json.tooltip = tooltip;
            json.xAxis = xAxis;
            json.yAxis = yAxis; 
            json.legend = legend;  
            json.exporting = exporting;   
            json.series = series;
            json.plotOptions = plotOptions;
   
            Highcharts.setOptions({
               global: {
                  useUTC: false
               }
            });
            $('#container').highcharts(json);
         });
      </script>
   </body>
   
</html>
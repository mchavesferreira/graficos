<!DOCTYPE HTML><html>
<head>
<link rel="stylesheet" type="text/css" href="https://github.highcharts.com/3f1a543407/css/dashboards/gui.css">
<link rel="stylesheet" type="text/css" href="https://github.highcharts.com/3f1a543407/css/datagrid.css">

<script src="https://github.highcharts.com/3f1a543407/dashboards.js"></script>
<script src="https://github.highcharts.com/3f1a543407/datagrid.js"></script>
<script src="https://github.highcharts.com/3f1a543407/highcharts.js"></script>
<script src="https://github.highcharts.com/3f1a543407/highcharts-more.js"></script>
<script src="https://github.highcharts.com/3f1a543407/modules/accessibility.js"></script>
<script src="https://github.highcharts.com/3f1a543407/modules/dashboards-plugin.js"></script>
<script src="https://github.highcharts.com/3f1a543407/modules/map.js"></script>
<script src="https://code.highcharts.com/modules/solid-gauge.js"></script>
<script src="https://github.highcharts.com/3f1a543407/modules/stock.js"></script>
<script src="https://github.highcharts.com/3f1a543407/modules/timeline.js"></script>

<style>
import "https://github.highcharts.com/3f1a543407/css/highcharts.css";

/* *
 *
 *  Colors
 *
 * */

#city-chart {
    --color-axis: #f7f7f7;
    --color-axis-labels: #e7e7ec;
    --color-background: #5352be;
    --color-title: #f0f0f0;
    --color-text: #000;
    --color-tooltip-background: #dadae2;
}

#kpi-layout {
    --color-axis-labels: #a7a4b0;
    --color-background: #fff;
    --color-gauge: #4caffe;
    --color-hover: #5352be;
    --color-hover-text: #fff;
    --color-pane: #eee;
    --color-pane-line: #ccc;
    --color-text: #2f2b38;
}

.highcharts-dashboards.hd-dark-mode #kpi-layout {
    --color-axis-labels: #838394;
    --color-background: #0d0d0d;
    --color-pane: #20202c;
    --color-pane-line: #838394;
    --color-text: #dadae2;
}

#selection-grid {
    --color-background: #fff;
    --color-border: #e0e0e0;
    --color-header-background: #dadae2;
    --color-header-border: #f7f7f7;
    --color-header-text: #20202c;
    --color-hover-background: #5352be;
    --color-hover-border: #e7e7ec;
    --color-hover-text: #e7e7ec;
    --color-input-background: #fff;
    --color-input-border: #5352be;
    --color-input-text: #20202c;
    --color-row-border: #e7e7ec;
    --color-row-text: #20202c;
    --color-row1-background: #fff;
    --color-row2-background: #f7f7f7;
}

.highcharts-dashboards.hd-dark-mode #selection-grid {
    --color-background: #20202c;
    --color-border: #4a4a53;
    --color-header-background: #0d0d0d;
    --color-header-border: #20202c;
    --color-header-text: #dadae2;
    --color-row-border: #838394;
    --color-row-text: #e7e7ec;
    --color-row1-background: #0d0d0d;
    --color-row2-background: #20202c;
}

#time-range-selector {
    --color-axis-labels: #646479;
    --color-background: #fafafa;
    --color-grid: #9a92ce;
    --color-handle: #5352be;
    --color-mask: #41378233;
    --color-mask-line: #9a92ce;
    --color-scroll: #f7f7f7;
    --color-scroll-line: #9a92ce;
    --color-series: #5352be;
    --color-thumb: #5352be;
    --color-thumb-line: #f7f7f7;
}

.highcharts-dashboards.hd-dark-mode #time-range-selector {
    --color-axis-labels: #e7e7ec;
    --color-background: #0d0d0d;
    --color-grid: #838394;
    --color-handle: #838394;
    --color-mask: #dddbef66;
    --color-mask-line: #838394;
    --color-scroll: #20202c;
    --color-scroll-line: #646479;
    --color-series: #5352be;
    --color-thumb: #5352be;
    --color-thumb-line: #838394;
}

#world-map {
    --color-background: #5352be;
    --color-map: #dddbef;
    --color-marker-border: #fff;
    --color-marker-text: #fff;
    --color-marker-text-border: #000;
    --color-navigation: #f7f7f7;
    --color-navigation-line: #838393;
    --color-navigation-text: #20202b;
    --color-text: #000;
    --color-text-border: #fff;
    --color-tooltip-background: #dadae2;
}

.highcharts-dashboards.hd-dark-mode #world-map {
    --color-navigation: #20202b;
    --color-navigation-line: #646478;
    --color-navigation-text: #838393;
}

@media (prefers-color-scheme: dark) {
    /* dark mode */

    .highcharts-dashboards {
        --color-dashboard: #46475d;
    }

    #kpi-layout {
        --color-axis-labels: #838394;
        --color-background: #0d0d0d;
        --color-pane: #20202c;
        --color-pane-line: #838394;
        --color-text: #dadae2;
    }

    #selection-grid {
        --color-background: #20202c;
        --color-border: #4a4a53;
        --color-header-background: #0d0d0d;
        --color-header-border: #20202c;
        --color-header-text: #dadae2;
        --color-row-border: #838394;
        --color-row-text: #e7e7ec;
        --color-row1-background: #0d0d0d;
        --color-row2-background: #20202c;
    }

    #time-range-selector {
        --color-axis-labels: #e7e7ec;
        --color-background: #0d0d0d;
        --color-grid: #838394;
        --color-mask: #dddbef66;
        --color-mask-line: #838394;
        --color-scroll: #20202c;
        --color-scroll-line: #646479;
        --color-series: #5352be;
        --color-thumb: #5352be;
        --color-thumb-line: #838394;
    }

    #world-map {
        --color-navigation: #20202b;
        --color-navigation-line: #646478;
        --color-navigation-text: #838393;
    }
}

/* *
 *
 *  Dashboard
 *
 * */

.highcharts-dashboards.hd-dark-mode {
    background-color: #46475d;
}

.highcharts-dashboards.hd-dark-mode .hd-edit-context-menu-btn {
    filter: invert(1);
}

/* *
 *
 *  City Chart
 *
 * */

#city-chart .hd-component-content {
    background: var(--color-background);
}

#city-chart .highcharts-background {
    fill: var(--color-background);
}

#city-chart .highcharts-title {
    fill: var(--color-title);
    font-size: 1.2em;
}

#city-chart .highcharts-axis {
    fill: var(--color-axis);
}

#city-chart .highcharts-axis-labels,
#city-chart .highcharts-axis-title {
    fill: var(--color-axis-labels);
}

#city-chart .highcharts-tooltip {
    fill: none;
    filter: none;
    stroke: none;
}

#city-chart div.highcharts-tooltip {
    color: var(--color-text);
}

#city-chart .highcharts-tooltip-box {
    fill: var(--color-tooltip-background);
    fill-opacity: 1;
    stroke: none;
}

/* *
 *
 *  KPI
 *
 * */

#kpi-layout .hd-component {
    background-color: var(--color-background);
    color: var(--color-text);
    cursor: pointer;
}

#kpi-layout .hd-component-kpi-content {
    background: none;
}

#kpi-layout .hd-component-kpi-chart-container {
    align-self: center;
    margin: auto;
}

#kpi-layout .hd-component-kpi-chart-container text {
    fill: var(--color-text);
}

#kpi-layout .hd-component-kpi-chart-container .highcharts-axis-labels text {
    fill: var(--color-axis);
}

#kpi-layout .hd-component-kpi-chart-container .highcharts-background {
    fill: none;
    stroke: none;
}

#kpi-layout .hd-component-kpi-chart-container .highcharts-label {
    font-size: 32px;
}

#kpi-layout .hd-component-kpi-chart-container .highcharts-pane {
    fill: var(--color-pane);
    fill-opacity: 1;
    stroke: var(--color-pane-line);
}

#kpi-layout .hd-component-kpi-chart-container .highcharts-series .highcharts-color-0 {
    fill: var(--color-gauge);
    stroke: none;
}

#kpi-layout .hd-component-kpi-chart-container .highcharts-title {
    font-size: 13px;
    font-weight: bold;
}

#kpi-layout .hd-cell-state-hover:hover .hd-component,
#kpi-layout .hd-cell-state-active .hd-component {
    background-color: var(--color-hover);
    color: var(--color-hover-text);
}

#kpi-layout .hd-cell-state-hover:hover text,
#kpi-layout .hd-cell-state-active text {
    fill: var(--color-hover-text);
}

#kpi-layout .hd-cell-state-hover:hover .highcharts-axis-labels text,
#kpi-layout .hd-cell-state-active .highcharts-axis-labels text {
    fill: var(--color-hover-text);
}

#kpi-data .hd-component {
    cursor: default;
}

#kpi-data .hd-component-kpi,
#kpi-data .hd-component-kpi-value-wrap {
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: space-evenly;
    text-align: center;
}

#kpi-data .hd-component-kpi > *,
#kpi-data .hd-component-kpi-value-wrap > * {
    align-self: center;
    flex: none;
    margin: auto;
}

#kpi-data .hd-component-title {
    margin: 1em;
}

#kpi-data .hd-component-title::before {
    content: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzMiIHZpZXdCb3g9IjAgMCAzMiAzMyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTE0LjczNTIgMzEuODU0NEM1LjQyMTIzIDE4LjY4OTQgMy42OTIzOCAxNy4zMzgzIDMuNjkyMzggMTIuNUMzLjY5MjM4IDUuODcyNTYgOS4yMDI3IDAuNSAxNi4wMDAxIDAuNUMyMi43OTc0IDAuNSAyOC4zMDc4IDUuODcyNTYgMjguMzA3OCAxMi41QzI4LjMwNzggMTcuMzM4MyAyNi41Nzg5IDE4LjY4OTQgMTcuMjY0OSAzMS44NTQ0QzE2LjY1MzcgMzIuNzE1MiAxNS4zNDY0IDMyLjcxNTIgMTQuNzM1MiAzMS44NTQ0Wk0xNi4wMDAxIDE3LjVDMTguODMyMyAxNy41IDIxLjEyODMgMTUuMjYxNCAyMS4xMjgzIDEyLjVDMjEuMTI4MyA5LjczODU2IDE4LjgzMjMgNy41IDE2LjAwMDEgNy41QzEzLjE2NzggNy41IDEwLjg3MTkgOS43Mzg1NiAxMC44NzE5IDEyLjVDMTAuODcxOSAxNS4yNjE0IDEzLjE2NzggMTcuNSAxNi4wMDAxIDE3LjVaIiBmaWxsPSIjOUE5MkNFIi8+Cjwvc3ZnPgo=);
    display: inline-block;
    margin-right: 0.25em;
    vertical-align: middle;
}

#kpi-data .hd-component-kpi-value-wrap {
    height: 100%;
}

#kpi-data .hd-component-kpi-value::before {
    content: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzMiIHZpZXdCb3g9IjAgMCAzMiAzMyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTMxLjc0NTggMjkuNDE4OEwxNy4zNDYgMS40MTg3NUMxNy4wNTE1IDAuODQ2MjUgMTYuNTQ0NSAwLjUgMTYgMC41QzE1LjQ1NTUgMC41IDE0Ljk0ODUgMC44NDYyNSAxNC42NTQgMS40MTg3NUwwLjI1NDE1NSAyOS40MTg4QzAuMDk4NzU4MSAyOS43MjA5IDAuMDExMzIwOCAzMC4wNjk4IDAuMDAxMDI3MTcgMzAuNDI4N0MtMC4wMDkyNjY0NiAzMC43ODc3IDAuMDU3OTYzNSAzMS4xNDM1IDAuMTk1NjU1IDMxLjQ1ODdDMC4zMzM0MTEgMzEuNzczOSAwLjUzNjUxOCAzMi4wMzcgMC43ODM2NDggMzIuMjIwMkMxLjAzMDc4IDMyLjQwMzQgMS4zMTI4MSAzMi41IDEuNjAwMTQgMzIuNUgzMC4zOTk5QzMwLjk4NTQgMzIuNSAzMS41MjM4IDMyLjEwMDYgMzEuODA0MyAzMS40NTgxQzMxLjk0MiAzMS4xNDMgMzIuMDA5MyAzMC43ODczIDMxLjk5OSAzMC40Mjg0QzMxLjk4ODcgMzAuMDY5NSAzMS45MDEyIDI5LjcyMDggMzEuNzQ1OCAyOS40MTg4Wk0xNiA2LjE5ODc1TDIwLjI2OTUgMTQuNUgxNkwxMi44IDE4LjVMMTAuODk3MSAxNi4xMjEzTDE2IDYuMTk4NzVaIiBmaWxsPSIjOUE5MkNFIi8+Cjwvc3ZnPgo=);
    display: inline-block;
    margin-right: 0.25em;
    vertical-align: middle;
}

/* *
 *
 *  Selection Grid
 *
 * */

#selection-grid .hd-component {
    background-color: var(--color-background);
    padding: 14px;
}

#selection-grid .hc-dg-container {
    border: none;
    height: 372px;
    overflow: auto;
}

#selection-grid .hc-dg-column-header {
    background-color: var(--color-header-background);
    border-color: var(--color-header-border);
    color: var(--color-header-text);
    padding: 0 12px;
}

#selection-grid .hc-dg-outer-container {
    background-color: var(--color-background);
    color: var(--color-row-text);
}

#selection-grid .hc-dg-cell {
    border-color: inherit;
}

#selection-grid .hc-dg-row {
    background-color: var(--color-row1-background);
    border-color: var(--color-row-border);
}

#selection-grid .hc-dg-row:nth-child(even) {
    background-color: var(--color-row2-background);
}

#selection-grid .hc-dg-row.hovered {
    background-color: var(--color-hover-background);
    border-color: var(--color-hover-border);
    color: var(--color-hover-text);
}

#selection-grid .hc-dg-cell-input {
    background: var(--color-input-background);
    border: 2px solid var(--color-input-border);
    color: var(--color-input-text);
}

/* *
 *
 *  Time Range Selector
 *
 * */

#time-range-selector .hd-component-content {
    background: var(--color-background);
}

#time-range-selector .highcharts-background {
    fill: var(--color-background);
}

#time-range-selector .highcharts-grid-line {
    stroke: var(--color-grid);
}

#time-range-selector .highcharts-navigator-handle {
    fill: var(--color-thumb);
    stroke: var(--color-thumb);
}

#time-range-selector .highcharts-navigator-mask-inside {
    fill: var(--color-mask);
    fill-opacity: 1;
    stroke: var(--color-mask-line);
    transform: translate(-1px, 0);
}

#time-range-selector .highcharts-navigator-outline {
    display: none;
}

#time-range-selector .highcharts-navigator-series {
    fill: none;
    stroke: var(--color-series);
}

#time-range-selector .highcharts-navigator-series.highcharts-column-series .highcharts-point {
    fill: var(--color-series);
}

#time-range-selector .highcharts-scrollbar-arrow {
    fill: var(--color-scroll-line);
    stroke: var(--color-scroll-line);
}

#time-range-selector .highcharts-scrollbar-button {
    fill: none;
    stroke: none;
}

#time-range-selector .highcharts-scrollbar-thumb {
    fill: var(--color-thumb);
    stroke-width: 0;
    transform: translate(-1px, 0);
}

#time-range-selector .highcharts-scrollbar-thumb + path {
    stroke: var(--color-thumb-line);
}

#time-range-selector .highcharts-scrollbar-track {
    fill: var(--color-scroll);
    stroke: var(--color-scroll-line);
}

#time-range-selector .highcharts-axis-labels {
    fill: var(--color-axis-labels);
}

/* *
 *
 *  World Map
 *
 * */

#world-map .hd-component-content {
    background: var(--color-background);
}

#world-map .highcharts-background {
    fill: var(--color-background);
}

#world-map .highcharts-credits {
    fill: var(--color-map);
}

#world-map .highcharts-halo {
    display: none;
}

#world-map .highcharts-map-navigation {
    fill: var(--color-navigation);
    font-size: 20px;
    stroke: var(--color-navigation-line);
}

#world-map .highcharts-map-navigation text {
    fill: var(--color-navigation-text);
}

#world-map .highcharts-series-0 .highcharts-point {
    fill: var(--color-map);
    stroke: var(--color-background);
}

#world-map .highcharts-series-0.highcharts-series-inactive {
    opacity: 0.6;
}

#world-map .highcharts-series-1 .highcharts-data-label:nth-child(odd) {
    font-size: 9px;
}

#world-map .highcharts-series-1 .highcharts-data-label text {
    fill: var(--color-text);
    paint-order: stroke;
    stroke: var(--color-text-border);
    stroke-width: 2px;
}

#world-map .highcharts-series-1 .highcharts-data-label:nth-child(even) {
    pointer-events: none;
}

#world-map .highcharts-series-1 .highcharts-data-label:nth-child(even) text {
    fill: var(--color-marker-text);
    stroke: var(--color-marker-text-border);
    stroke-width: 1.5px;
}

#world-map .highcharts-series-1 .highcharts-point {
    paint-order: stroke;
    stroke: var(--color-marker-border);
    stroke-width: 2;
    cursor: pointer;
}

#world-map .highcharts-series-1 .highcharts-point:hover,
#world-map .highcharts-series-1 .highcharts-point-select {
    stroke-width: 6;
}

#world-map .highcharts-tooltip {
    fill: none;
    filter: none;
    stroke: none;
}

#world-map div.highcharts-tooltip {
    color: var(--color-text);
}

#world-map .highcharts-tooltip-box {
    fill: var(--color-tooltip-background);
    fill-opacity: 1;
    stroke: none;
}

#world-map .highcharts-zoom-in text {
    transform: translate(1px, -1px);
}

#world-map .highcharts-zoom-out text {
    transform: translate(2px, -1px);
}

/* Safari fix for manual dark mode */
.highcharts-dashboards.hd-dark-mode #world-map .highcharts-series-1 .highcharts-data-label text {
    paint-order: stroke;
    stroke-width: 2px;
}

/* *
 *
 *  Edit mode
 *
 * */

.hd-edit-button.hd-edit-tools-btn {
    background-position: top left;
    background-color: #e7e7ec;
    border-radius: 4px;
    margin: 10px;
}

.hd-edit-button.hd-edit-tools-btn:hover {
    background-color: #646479;
    color: #fff;
}

.hd-edit-enabled.highcharts-dashboards {
    background-color: rgba(36, 29, 58, 0.2);
}

.hd-edit-toolbar-cell > .hd-edit-menu-item.hd-edit-toolbar-item {
    background: #241d3a;
    border-radius: 2px;
}

.hd-edit-toolbar-row > .hd-edit-menu-item.hd-edit-toolbar-item {
    background: #646479;
    border-radius: 2px;
}

.hd-layout > .hd-row.hd-edit-row-context-highlight {
    background:
        repeating-linear-gradient(
            -45deg,
            #9491a1,
            #9895a4 10px,
            rgb(169 167 188) 10px,
            rgb(169 167 188) 12px
        );
}

.hd-edit-toolbar > .hd-edit-toolbar-cell-outline {
    border: 2px solid #241d3a;
}

.hd-edit-toolbar > .hd-edit-toolbar-row-outline {
    border: 2px solid #646479;
}

.hd-edit-menu.hd-edit-toolbar-row {
    background: #646479;
}

.highcharts-dashboards > .hd-edit-drop-pointer {
    background: #ff8d64;
}

</style>

</head>
<body>
<div id="container" class="highcharts-dashboards">Loading...</div>

<p>
    You see agroclimatic data based on the NorESM1-M model provided by the Norwegian Climate Centre on behalf of the Copernicus Climate Change Service.
    The data covers the time span from 1951 to 2010 as 10-day average with a temporal resolution of 10 years.
    The Copernicus Observation Programme uses historical data from ground and satellites.
    More information can be found at the
    <a href="https://cds.climate.copernicus.eu/cdsapp#!/dataset/sis-agroclimatic-indicators" rel="noreferrer" target="_blank">Climate Data Store</a>
    of the European Union.
</p>


</body>
<script>
/* eslint-disable prefer-const, jsdoc/require-description */
const dataPool = new Dashboards.DataOnDemand();
const dataScopes = {
    FD: 'Days with Frost',
    ID: 'Days with Ice',
    RR: 'Days with Rain',
    TN: 'Average Temperature',
    TX: 'Maximal Temperature'
};
const dataTemperatures = {
    C: 'Celsius',
    F: 'Farenheit',
    K: 'Kelvin'
};
const initialMin = Date.UTC(2010);
const minRange = 30 * 24 * 3600 * 1000; // 30 days
const maxRange = 2 * 365 * 24 * 3600 * 1000; // 2 years
const defaultCity = 'New York';
const defaultData = 'TXC';

let citiesData;
let citiesMap;
let citiesTable;
let cityGrid;
let cityScope = defaultCity;
let citySeries;
let dataScope = defaultData;
let navigatorSeries;
let worldDate = Date.UTC(2010, 11, 25); // months start with 0
let kpis = {};
let darkMode = false;
let temperatureScale = 'C';

async function setupDashboard() {

    citiesData = await buildCitiesData();
    buildSymbols();

    const defaultCityStore = await dataPool.getStore(defaultCity);
    const map = await fetch(
        'https://code.highcharts.com/mapdata/custom/world.topo.json'
    ).then(response => response.json());
    const mapPoints = await buildCitiesMap();

    return new Promise(resolve => new Dashboards.Dashboard('container', {
        components: [{
            cell: 'time-range-selector',
            type: 'Highcharts',
            chartOptions: {
                chart: {
                    height: '80px',
                    styledMode: true
                },
                credits: {
                    enabled: false
                },
                legend: {
                    enabled: false
                },
                title: {
                    text: ''
                },
                tooltip: {
                    enabled: false
                },
                series: [{
                    type: 'spline',
                    name: 'Timeline',
                    data: buildDates(),
                    showInNavigator: false,
                    marker: {
                        enabled: false
                    },
                    states: {
                        hover: {
                            enabled: false
                        }
                    }
                }],
                navigator: {
                    enabled: true,
                    handles: {
                        symbols: ['leftarrow', 'rightarrow'],
                        lineWidth: 0,
                        width: 8,
                        height: 14
                    },
                    series: [{
                        name: defaultCity,
                        data: defaultCityStore.table.modified.getRows(
                            void 0,
                            void 0,
                            ['time', dataScope]
                        ),
                        animation: false,
                        animationLimit: 0
                    }],
                    xAxis: {
                        endOnTick: true,
                        gridZIndex: 4,
                        labels: {
                            x: 1,
                            y: 22
                        },
                        opposite: true,
                        showFirstLabel: true,
                        showLastLabel: true,
                        startOnTick: true,
                        tickPosition: 'inside'
                    },
                    yAxis: {
                        maxPadding: 0.5
                    }
                },
                scrollbar: {
                    enabled: true,
                    barBorderRadius: 0,
                    barBorderWidth: 0,
                    buttonBorderWidth: 0,
                    buttonBorderRadius: 0,
                    height: 14,
                    trackBorderWidth: 0,
                    trackBorderRadius: 0
                },
                xAxis: {
                    visible: false,
                    min: initialMin,
                    minRange: minRange,
                    maxRange: maxRange,
                    events: {
                        afterSetExtremes: async function (e) {
                            const minValue = e.min || e.target.min;
                            const maxValue = e.max || e.target.max;
                            const table =
                                await dataPool.getStoreTable(cityScope);

                            table.setModifier(new Dashboards.RangeModifier({
                                ranges: [{
                                    column: 'time',
                                    minValue,
                                    maxValue
                                }]
                            }));

                            const data = table.modified.getRows(
                                void 0,
                                void 0,
                                ['time', dataScope]
                            );
                            const lastPoint = data[data.length - 1];
                            const startIndex =
                                table.getRowIndexBy('time', data[0][0]);

                            worldDate = lastPoint[0];

                            citiesMap.setData(await buildCitiesMap());

                            updateKPI(table.modified, worldDate);
                            updateKPIData();

                            cityGrid.scrollToRow(startIndex);
                            cityGrid.update(); // Force redraw;

                            citySeries.update({ data });
                        }
                    }
                },
                yAxis: {
                    visible: false
                }
            },
            events: {
                mount: function () {
                    navigatorSeries = this.chart.series[1];
                }
            }
        }, {
            cell: 'world-map',
            type: 'Highcharts',
            chartConstructor: 'mapChart',
            chartOptions: {
                chart: {
                    map,
                    styledMode: true
                },
                colorAxis: buildColorAxis(),
                legend: {
                    enabled: false
                },
                mapNavigation: {
                    buttonOptions: {
                        verticalAlign: 'bottom'
                    },
                    enabled: true,
                    enableMouseWheelZoom: false
                },
                mapView: {
                    maxZoom: 4
                },
                series: [{
                    type: 'map',
                    name: 'World Map'
                }, {
                    type: 'mappoint',
                    name: 'Cities',
                    data: mapPoints,
                    animation: false,
                    animationLimit: 0,
                    allowPointSelect: true,
                    dataLabels: [{
                        align: 'left',
                        animation: false,
                        crop: false,
                        enabled: true,
                        format: '{point.name}',
                        padding: 0,
                        verticalAlign: 'top',
                        x: -2,
                        y: 2
                    }, {
                        animation: false,
                        crop: false,
                        enabled: true,
                        formatter: function () {
                            return Math.round(this.y);
                        },
                        inside: true,
                        padding: 0,
                        verticalAlign: 'bottom',
                        y: -16
                    }],
                    events: {
                        click: async function (e) {

                            if (!cityGrid || !citySeries) {
                                return; // not ready
                            }

                            const point = e.point;
                            const city = point.name;

                            cityScope = city;
                            const store = await dataPool.getStore(city);

                            syncRefreshCharts(
                                store,
                                dataScope,
                                city
                            );

                            // Update DataGrid
                            cityGrid.dataTable = store.table;
                            cityGrid.update(); // force redraw

                            updateKPIData();
                        }
                    },
                    marker: {
                        enabled: true,
                        lineWidth: 2,
                        radius: 12,
                        states: {
                            hover: {
                                lineWidthPlus: 4,
                                radiusPlus: 0
                            },
                            select: {
                                lineWidthPlus: 4,
                                radiusPlus: 0
                            }
                        },
                        symbol: 'mapmarker'
                    },
                    tooltip: {
                        footerFormat: '',
                        headerFormat: '',
                        pointFormatter: function () {
                            const point = this;

                            return (
                                `<b>${point.name}</b><br>` +
                                tooltipFormatter(point.y, point.name)
                            );
                        }
                    }
                }],
                title: {
                    text: void 0
                },
                tooltip: {
                    enabled: true,
                    positioner: function (width, _height, axisInfo) {
                        return {
                            x: (
                                axisInfo.plotX -
                                this.options.padding
                            ),
                            y: (
                                axisInfo.plotY +
                                this.options.padding +
                                5
                            )
                        };
                    },
                    shape: 'rect',
                    useHTML: true
                }
            },
            events: {
                mount: function () {
                    // call action
                    citiesMap = this.chart.series[1];
                }
            }
        }, {
            cell: 'city-chart',
            type: 'Highcharts',
            sync: {
                tooltip: true
            },
            chartOptions: {
                chart: {
                    spacing: [40, 40, 40, 10],
                    styledMode: true
                },
                credits: {
                    enabled: false
                },
                colorAxis: buildColorAxis(),
                series: [{
                    type: 'spline',
                    name: defaultCity,
                    data: [],
                    animation: false,
                    animationLimit: 0,
                    events: {
                        afterAnimate: () => resolve()
                    },
                    legend: {
                        enabled: false
                    },
                    marker: {
                        enabledThreshold: 0.5
                    },
                    tooltip: {
                        footerFormat: '',
                        headerFormat: '',
                        pointFormatter: function () {
                            return tooltipFormatter(this.y);
                        }
                    }
                }],
                title: {
                    margin: 20,
                    text: dataScopes[dataScope.substring(0, 2)],
                    x: 15,
                    y: 5
                },
                tooltip: {
                    enabled: true
                },
                xAxis: {
                    type: 'datetime',
                    labels: {
                        formatter: function () {
                            return Highcharts.time.dateFormat(
                                '%e. %b',
                                this.value
                            );
                        }
                    }
                },
                yAxis: {
                    title: {
                        text: dataTemperatures[dataScope[2] || 'K']
                    }
                }
            },
            events: {
                mount: function () {
                    citySeries = this.chart.series[0];
                }
            }
        }, {
            cell: 'selection-grid',
            type: 'DataGrid',
            dataGridOptions: {
                cellHeight: 38,
                editable: false
            },
            editable: true,
            events: {
                mount: function () {
                    // call action
                    cityGrid = this.dataGrid;
                }
            },
            store: defaultCityStore,
            sync: {
                tooltip: true
            }
        }, {
            cell: 'kpi-data',
            type: 'KPI',
            dimensions: {
                height: 150
            },
            title: cityScope,
            value: 10,
            valueFormatter: v => `${v.toFixed(0)}m`,
            events: {
                mount: function () {
                    kpis.data = this;
                    updateKPIData();
                }
            }
        }, {
            cell: 'kpi-temperature',
            type: 'KPI',
            chartOptions: buildKPIChartOptions('TN' + temperatureScale),
            events: {
                mount: function () {
                    kpis.TN = this;
                },
                click: function () {
                    dataScope = 'TN' + temperatureScale;

                    syncRefreshCharts(
                        citiesData[cityScope].store,
                        dataScope,
                        cityScope
                    );
                }
            },
            states: {
                active: {
                    enabled: true
                },
                hover: {
                    enabled: true
                }
            }
        }, {
            cell: 'kpi-max-temperature',
            type: 'KPI',
            chartOptions: buildKPIChartOptions('TX' + temperatureScale),
            events: {
                mount: function () {
                    kpis.TX = this;
                },
                click: function () {
                    dataScope = 'TX' + temperatureScale;

                    syncRefreshCharts(
                        citiesData[cityScope].store,
                        dataScope,
                        cityScope
                    );
                },
                afterLoad: function () {
                    this.parentCell.setActiveState();
                }
            },
            states: {
                active: {
                    enabled: true
                },
                hover: {
                    enabled: true
                }
            }
        }, {
            cell: 'kpi-rain',
            type: 'KPI',
            chartOptions: buildKPIChartOptions('RR1'),
            events: {
                mount: function () {
                    kpis.RR1 = this;
                },
                click: function () {
                    dataScope = 'RR1';

                    syncRefreshCharts(
                        citiesData[cityScope].store,
                        dataScope,
                        cityScope
                    );
                }
            },
            states: {
                active: {
                    enabled: true
                },
                hover: {
                    enabled: true
                }
            }
        }, {
            cell: 'kpi-ice',
            type: 'KPI',
            chartOptions: buildKPIChartOptions('ID'),
            events: {
                mount: function () {
                    kpis.ID = this;
                },
                click: function () {
                    dataScope = 'ID';

                    syncRefreshCharts(
                        citiesData[cityScope].store,
                        dataScope,
                        cityScope
                    );
                }
            },
            states: {
                active: {
                    enabled: true
                },
                hover: {
                    enabled: true
                }
            }
        }, {
            cell: 'kpi-frost',
            type: 'KPI',
            chartOptions: buildKPIChartOptions('FD'),
            events: {
                mount: function () {
                    kpis.FD = this;
                },
                click: function () {
                    dataScope = 'FD';

                    syncRefreshCharts(
                        citiesData[cityScope].store,
                        dataScope,
                        cityScope
                    );
                }
            },
            states: {
                active: {
                    enabled: true
                },
                hover: {
                    enabled: true
                }
            }
        }],
        editMode: {
            enabled: true,
            contextMenu: {
                enabled: true,
                icon: (
                    'https://code.highcharts.com/gfx/dashboard-icons/menu.svg'
                ),
                items: [
                    'editMode',
                    {
                        id: 'dark-mode',
                        type: 'toggle',
                        text: 'Dark mode',
                        events: {
                            click: function () {
                                const dashboard = this.menu.editMode.dashboard,
                                    darModeClass =
                                        Dashboards.classNamePrefix + 'dark-mode';

                                darkMode = !darkMode;

                                if (darkMode) {
                                    dashboard.container.classList
                                        .add(darModeClass);
                                } else {
                                    dashboard.container.classList
                                        .remove(darModeClass);
                                }
                            }
                        }
                    }, {
                        id: 'fahrenheit',
                        type: 'toggle',
                        text: 'Fahrenheit',
                        events: {
                            click: function () {
                                // Change temperature scale.
                                temperatureScale = temperatureScale === 'C' ? 'F' : 'C';
                                dataScope = 'TX' + temperatureScale;

                                // Update the dashboard.
                                syncRefreshCharts(
                                    citiesData[cityScope].store,
                                    dataScope,
                                    cityScope
                                );
                                updateKPI(
                                    citiesData[cityScope].store.table.modified,
                                    worldDate
                                );
                            }
                        }
                    }
                ]
            }
        },
        gui: {
            enabled: true,
            layouts: [{
                id: 'layout-1', // mandatory
                rows: [{
                    cells: [{
                        id: 'time-range-selector',
                        width: '100%'
                    }]
                }, {
                    cells: [{
                        id: 'world-map',
                        width: '50%'
                    }, {
                        id: 'kpi-layout',
                        width: '50%',
                        layout: {
                            rows: [{
                                cells: [{
                                    id: 'kpi-data',
                                    width: '33.333%'
                                }, {
                                    id: 'kpi-temperature',
                                    width: '33.333%'
                                }, {
                                    id: 'kpi-max-temperature',
                                    width: '33.333%'
                                }]
                            }, {
                                cells: [{
                                    id: 'kpi-rain',
                                    width: '33.333%'
                                }, {
                                    id: 'kpi-ice',
                                    width: '33.333%'
                                }, {
                                    id: 'kpi-frost',
                                    width: '33.333%'
                                }]
                            }],
                            style: {
                                height: '204px'
                            }
                        }
                    }]
                }, {
                    cells: [{
                        id: 'selection-grid',
                        width: '50%'
                    }, {
                        id: 'city-chart',
                        width: '50%'
                    }],
                    style: {
                        height: '414px'
                    }
                }]
            }]
        }
    }));
}

async function setupDataPool() {

    dataPool.setStoreOptions({
        name: 'cities',
        storeOptions: {
            csvURL: 'https://www.highcharts.com/samples/data/climate-cities.csv'
        },
        storeType: 'CSVStore'
    });

    citiesTable = await dataPool.getStoreTable('cities');

    for (const row of citiesTable.getRowObjects()) {
        dataPool.setStoreOptions({
            name: row.city,
            storeOptions: {
                csvURL: row.csv
            },
            storeType: 'CSVStore'
        });
    }
}

async function setupCitiesData() {
    const cities = citiesTable.modified;
    const data = citiesData;
    const promises = [];
    const rows = cities.getRows(
        void 0,
        void 0,
        ['lat', 'lon', 'city', 'country', 'elevation']
    );

    for (const row of rows) {
        const city = row[2];

        if (!data[city]) {
            promises.push(
                dataPool
                    .getStore(city)
                    .then(store => {
                        decorateCityTable(store.table);
                        data[city] = {
                            country: row[3],
                            elevation: row[4],
                            lat: row[0],
                            lon: row[1],
                            name: row[2],
                            store
                        };
                    })
            );
        }
    }

    await Promise.all(promises);

    if (citiesMap) {
        citiesMap.setData(await buildCitiesMap());
    }
}

async function main() {
    await setupDataPool();
    await setupDashboard();
    await setupCitiesData();
}

main().catch(e => console.error(e));

/* *
 *
 *  Helper Functions
 *
 * */

async function buildCitiesData() {
    const cities = citiesTable.modified;
    const data = {};
    const initialRow = await cities.getRow(
        cities.getRowIndexBy('city', cityScope),
        ['lat', 'lon', 'city', 'country', 'elevation']
    );
    const store = await dataPool.getStore(initialRow[2]);

    await decorateCityTable(store.table);

    data[cityScope] = {
        country: initialRow[3],
        elevation: initialRow[4],
        lat: initialRow[0],
        lon: initialRow[1],
        name: initialRow[2],
        store
    };

    return data;
}

async function buildCitiesMap() {
    return Object
        .keys(citiesData)
        .map(city => {
            const data = citiesData[city];
            const table = data.store.table.modified;
            const y = table.getCellAsNumber(
                dataScope,
                table.getRowIndexBy('time', worldDate)
            ) || 0;

            return {
                lat: data.lat,
                lon: data.lon,
                name: data.name,
                selected: city === cityScope,
                y
            };
        })
        .sort(city => city.lat);
}

function buildColorAxis() {

    // temperature
    if (dataScope[0] === 'T') {
        return {
            visible: false,
            startOnTick: false,
            endOnTick: false,
            max: dataScope[2] === 'C' ? 50 : 122,
            min: dataScope[2] === 'C' ? 0 : 32,
            stops: buildColorStops(dataScope)
        };
    }

    // days
    return {
        max: 10,
        min: 0,
        visible: false,
        stops: buildColorStops(dataScope)
    };
}

function buildColorStops(dataScope) {

    // temperature
    if (dataScope[0] === 'T') {
        return [
            [0.0, '#4CAFFE'],
            [0.3, '#53BB6C'],
            [0.5, '#DDCE16'],
            [0.6, '#DF7642'],
            [0.7, '#DD2323']
        ];
    }

    // days
    return [
        [0.0, '#C2CAEB'],
        [1.0, '#162870']
    ];
}

function buildDates() {
    const dates = [];

    for (let date = new Date(Date.UTC(1951, 0, 5)),
        dateEnd = new Date(Date.UTC(2010, 11, 25));
        date <= dateEnd;
        date = date.getUTCDate() >= 25 ?
            new Date(Date.UTC(
                date.getFullYear(),
                date.getUTCMonth() + 1,
                5
            )) :
            new Date(Date.UTC(
                date.getFullYear(),
                date.getUTCMonth(),
                date.getUTCDate() + 10
            ))
    ) {
        dates.push([date.getTime(), 0]);
    }

    return dates;
}

function buildKPIChartOptions(dataScope) {
    return {
        chart: {
            height: 166,
            margin: [8, 8, 16, 8],
            spacing: [8, 8, 8, 8],
            styledMode: true,
            type: 'solidgauge'
        },
        pane: {
            background: {
                innerRadius: '90%',
                outerRadius: '120%',
                shape: 'arc'
            },
            center: ['50%', '70%'],
            endAngle: 90,
            startAngle: -90
        },
        series: [{
            data: [(() => {
                const table = citiesData[cityScope].store.table.modified;
                return table.getCellAsNumber(
                    dataScope,
                    table.getRowIndexBy('time', worldDate)
                ) || 0;
            })()],
            dataLabels: {
                formatter: function () {
                    return Math.round(this.y);
                },
                y: -34
            },
            enableMouseTracking: false,
            innerRadius: '90%',
            radius: '120%'
        }],
        title: {
            margin: 0,
            text: dataScopes[dataScope.substring(0, 2)],
            verticalAlign: 'bottom',
            widthAdjust: 0
        },
        yAxis: {
            labels: {
                distance: 4,
                y: 12
            },
            max: (
                dataScope[0] === 'T' ?
                    dataScope[2] === 'C' ? 50 : 122 :
                    10
            ),
            min: (
                dataScope[0] === 'T' ?
                    dataScope[2] === 'C' ? -10 : 14 :
                    0
            ),
            minorTickInterval: null,
            stops: buildColorStops(dataScope),
            tickAmount: 2,
            visible: true
        }
    };
}

function buildSymbols() {
    // left arrow
    Highcharts.SVGRenderer.prototype.symbols.leftarrow = (x, y, w, h) => [
        'M', x + w / 2 - 1, y,
        'L', x + w / 2 - 1, y + h,
        x - w / 2 - 1, y + h / 2,
        'Z'
    ];
    // right arrow
    Highcharts.SVGRenderer.prototype.symbols.rightarrow = (x, y, w, h) => [
        'M', x + w / 2 + 1, y,
        'L', x + w / 2 + 1, y + h,
        x + w + w / 2 + 1, y + h / 2,
        'Z'
    ];
}

function decorateCityTable(table) {
    const columns = ['TN', 'TX'], // Average, Maximal temperature
        scales = ['C', 'F'];

    columns.forEach(column => {
        scales.forEach(scale => {
            const newColumn = column + scale;
            let temperatureColumn = table.getColumn(newColumn);

            if (!temperatureColumn) {
                table.setColumns({
                    [newColumn]: table
                        .getColumn(column)
                        .map(kelvin => Highcharts.correctFloat(
                            scale === 'C' ?
                                (kelvin - 273.15) :
                                (kelvin * 1.8 - 459.67),
                            3
                        ))
                });
            }
        });
    });

    table.setColumn(
        'Date',
        table
            .getColumn('time')
            .map(timestamp => new Date(timestamp)
                .toISOString()
                .substring(0, 10)
            )
    );

    table.setColumnAlias('avg. ˚C', 'TNC');
    table.setColumnAlias('avg. ˚F', 'TNF');
    table.setColumnAlias('avg. ˚K', 'TN');
    table.setColumnAlias('max ˚C', 'TXC');
    table.setColumnAlias('max ˚F', 'TXF');
    table.setColumnAlias('max ˚K', 'TX');
    table.setColumnAlias('Frost', 'FD');
    table.setColumnAlias('Ice', 'ID');
    table.setColumnAlias('Rain', 'RR1');

}

function tooltipFormatter(value, city) {
    let tooltip = '';

    if (city) {
        tooltip += `Elevation: ${citiesData[city].elevation}m<br>`;
    }

    // temperature values (original Kelvin)
    if (dataScope[0] === 'T') {

        if (dataScope[2] === 'C') {
            tooltip += value + '˚C<br>';
        }

        if (dataScope[2] === 'F') {
            tooltip += value + '˚F<br>';
        }

    // rain days
    } else if (dataScope === 'RR1') {
        tooltip += Highcharts.correctFloat(value, 0) + ' rainy days';

    // ice days
    } else if (dataScope === 'ID') {
        tooltip += Highcharts.correctFloat(value, 0) + ' icy days';

    // frost days
    } else if (dataScope === 'FD') {
        tooltip += Highcharts.correctFloat(value, 0) + ' frosty days';

    // fallback
    } else {
        tooltip += Highcharts.correctFloat(value, 4);
    }

    return tooltip;
}

function updateKPI(table, time) {
    for (
        const [key, kpi] of Object.entries(kpis)
    ) {
        if (key === 'data') {
            continue;
        }
        kpi.update({
            chartOptions: {
                series: [{
                    data: [
                        table.getCellAsNumber(
                            key + (key[0] === 'T' ? temperatureScale : ''),
                            table.getRowIndexBy('time', time)
                        ) || 0
                    ]
                }]
            }
        });
    }
}

function updateKPIData() {
    const data = citiesData[cityScope];

    // update KPI data
    kpis.data.update({
        title: data.name,
        value: data.elevation,
        subtitle: 'Elevation'
    });
}

function syncRefreshCharts(store, dataScope, cityScope) {
    const data = store.table.getRows(
        void 0, void 0,
        ['time', dataScope]
    );
    const isColumnSeries = ['RR1', 'FD', 'ID'].indexOf(dataScope) >= 0;
    const columnSeriesOptions = {
        type: isColumnSeries ? 'column' : 'spline',
        threshold: isColumnSeries ? 0 : null
    };

    // update navigator
    navigatorSeries.update({
        name: cityScope,
        minPointLength: 1, // workaround
        pointPadding: 0,
        groupPadding: 0,
        crisp: false,
        data,
        ...columnSeriesOptions
    });

    // update chart
    citySeries.chart.update({
        title: {
            text: cityScope
        }
    }, false);

    citySeries.update(columnSeriesOptions);

    // Update the main chart
    Highcharts.fireEvent(
        navigatorSeries.chart.xAxis[0],
        'afterSetExtremes'
    );

    // update colorAxis
    citiesMap.chart.update({
        colorAxis: buildColorAxis()
    });

    citySeries.chart.update({
        colorAxis: buildColorAxis(),
        title: {
            text: dataScopes[dataScope.substring(0, 2)]
        },
        yAxis: {
            title: {
                text: (
                    dataScope[0] === 'T' ?
                        dataTemperatures[dataScope[2] || 'K'] :
                        'Days'
                )
            }
        }
    });

    buildCitiesMap().then(data => {
        citiesMap.setData(data);
    });
}

</script>
</html>

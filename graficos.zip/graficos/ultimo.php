<?php
  header('Content-Type: application/json');
  $temperature = array(
    'time' => array('00:00', '01:00', '02:00', '03:00', '04:00'),
    'data' => array(20, 21, 22, 19, 18)
  );
  echo json_encode($temperature);
?>

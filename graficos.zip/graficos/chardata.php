<?php

header('Content-type: text/json');

//Placeholder - random data for now
$x1 = "2023-1-1";
$y1 = rand(0, 100);

$x2 = "2023-1-2";
$y2 = rand(0, 100);

//Generate this array from database data
$arr = array($x1 => $y1, $x2 => $y2);

echo json_encode($arr);

?>